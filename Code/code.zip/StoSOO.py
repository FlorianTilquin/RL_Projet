#! /usr/bin/env python
# -*- encoding : utf-8 -*-

import numpy as np
import numpy.random as rd

def rew(f,node) :
	H,I = node
	alpha,beta = (I-1.)/2.**H,I/2.**H
	X = rd.uniform(alpha,beta)
	return f(X),X

def SOO(f,n,k,hmax,delta,noise):
	param = np.log(n*k/delta)
	T = [[0,1]]	#Initialisation classique
	t = 0 # Nombre d'evaluataions de la fonction effectuees
	MU= [0] # La moyenne des evaluations de la fonction au noeud correspondant dans T (MU[i] = moy des Y pour T[i])
	N = [0] # Nombre d'evaluations faites au noeud T[i]
	b = [np.inf] # B values calculees sur la base de MU + coefficient correctif
	REW = []
	P = []
	depth = 0
	while t < n :
		if t%50 == 0:
			print t
		bmax = -np.inf
		for h in xrange(min(depth,hmax)+1) :
			#print "T",T
			bmax2 = -np.inf
			Lh = [j for j,[p,i] in enumerate(T) if( p == h and ([h+1,2*i] not in T) )] # tous les (indices des) feuilles de T a profondeur h
			if Lh != []:
				for i in Lh :# on calcule les b-values de tous les noeuds a profondeur h
					if b[i]>=bmax2 :
						im = i
						bmax2 = b[i]
				if bmax2 >= bmax :
					[H,I] = T[im]
					if N[im] < k :
						r,X = rew(f,[H,I])
						r = r + rd.randn()*noise-noise*0.5
						REW.append(r)
						P.append(X)
						N[im] = N[im] + 1
						MU[im] = (1-1./N[im])*MU[im] + r/N[im]
						b[im] = MU[im] + np.sqrt(param/(2.*N[im]))
						t = t+1
						hp,ip = H-1,(I+1)/2
						while [hp,ip] in T:
							Ip = T.index([hp,ip])
							N[Ip] = N[Ip] + 1
							MU[Ip] = (1-1./N[Ip])*MU[Ip] + r/N[Ip]
							b[Ip] = MU[Ip] + np.sqrt(param/(2.*N[Ip]))
							hp,ip = hp-1,(ip+1)/2
					else :
						for s in [[H+1,2*I-1],[H+1,2*I]]:
							if s not in T:
								T.append(s)
								alpha,beta = (s[1]-1.)/2.**s[0],s[1]/2.**s[0]
								Pchild = [i for i,j in enumerate(P) if (j>=alpha)*(j<=beta)]
								if Pchild != []:
									N.append(len(Pchild))
									mu = np.mean([REW[i] for i in Pchild])
									MU.append(mu)
									b.append(mu  + np.sqrt(param/(2.*len(Pchild))) )
								else :
									N.append(0)
									MU.append(0)
									b.append(np.inf)
						bmax = b[im]
						if depth != H+1:
							depth = H+1
	hm = min(depth,hmax)
	MUh = [[MU[j],i] for j,[h,i] in enumerate(T) if h == hm]
	MUh = np.array(MUh)
	im = MUh[np.argmax(MUh[:,0]),1]
	return (2*im-1.)/2**(hm+1),P,REW # Milieu du meilleur segment
