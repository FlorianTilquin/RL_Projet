#! /usr/bin/env python
# -*- coding: utf-8 -*-

import numpy.random as rd
import matplotlib.pyplot as plt
from scipy.optimize import fmin
from time import time as ti
from fonctions import *
from ATB import ATB
from HOO import HOO
from HCT2 import *
from POO import POO
from StoSOO import SOO



#f = sinprod
#f = sqr
#f = garland
f = grill

if(f==sinprod):
	Xm = 0.867526208796
	Ym = f(Xm)

if(f==garland):
	Xm = 0.523598775599
	Ym = f(Xm)

if(f== grill):
	Xm = 0.5
	Ym = 1.


###################################################

######### Noise ###################################
noise = 1.
n = 1000
#f = lambda x: g(x) + rd.randn()*noise


######### Algorithms application ##################
####  ATB ####
# Default parameters
eps = 10**-6
##gamma = 1.85
nu = 3.2 # 2.5<nu<3.5
depth = 15
def_ATB = [depth,eps,nu,noise]
#n = 500
#T,A,Mu,N,R,I,P_ATB,REW_ATB = ATB(f,n,depth,eps,nu)#,noise)
#print len(T),len(REW_ATB)
#[hm,im] = T[np.argmax(REW_ATB)]
##xm = (2*im-1.)/2**(hm+1)
#xm = P_ATB[np.argmax(REW_ATB)]
#ym = np.max(REW_ATB)
##ym = f(xm)
#print xm,ym

####  HOO  ####
# Default parameters
nu = 1.
rho= 0.6
#def_HOO = [nu,rho,noise]
T,N,mu,B,P_HOO,REW_HOO = HOO(f,n,nu,rho,noise)
#[hm,im] = T[np.argmax(mu)]
#xm = (2*im-1.)/2**(hm+1)
#ym = f(xm)
#print xm,ym

#### POO ####
rhomax = 0.8
numax = 1.
def_POO = [rhomax,numax,noise]
#H, = POO(f,n,K,rhomax,numax)
#T = H[0]
#mu = H[2]
#print len(mu)
#P_POO = H[6]
#REW_POO = H[7]
#im = np.argmax(mu)
#[h,i] = T[im]
#xm = (2*i-1.)/2**(h+1)
#ym = f(xm)
#print Xm,Ym
#print xm,ym

#### SOO ####
k = (np.ceil(n/np.log(n)**3))
hmax = np.ceil(np.log(n)**1.5)
delta = np.sqrt(1./n)
def_SOO = [k,hmax,delta,noise]
#noise = 0.2
#xm,P_SOO,REW_SOO = SOO(f,n,k,hmax,delta,noise)
#ym = f(xm)
#print xm, ym
#print abs(Xm-xm),abs(Ym-ym)

#### HCT_iid ####
# Parameters
#n = 5000
rho = 0.1
nu = 1.0
delta = 0.1
def_HCT = [rho,nu,delta,noise]
#T,N,Mu,U,B,D,P_HCT,REW_HCT = HCT(f,n,nu,rho,delta,noise)
##print N
##print len(T)
#im = np.argmax(Mu)
#[h,i] = T[im]
#xm = (2*i-1.)/2**(h+1)
#ym = f(xm)
#print xm,ym
#print abs(Xm-xm),abs(Ym-ym)

u = np.linspace(0,1,10001)
v = [f(x) for x in u]
plt.figure(100)
#plt.plot(xm,ym,'ro')
###plt.plot(Xm,Ym,'bo')
plt.plot(u,v,'.k')
###
###
###
plt.figure(1)
plt.title('Positions')
###plt.plot(P_HCT,np.arange(len(P_HCT)),'b+')
plt.plot(P_HOO,np.arange(len(P_HOO)),'r+')
####plt.plot(P_POO,np.arange(len(P_POO)),'c+')
####plt.plot(P_SOO,np.arange(len(P_SOO)),'g+')
####plt.plot(P_ATB,np.arange(len(P_ATB)),'m+')
###
####Ym = 0.
plt.figure(2)
plt.title('Marginal regret')
###plt.plot(Ym-np.array(REW_HCT),'b+')
plt.plot(Ym-np.array(REW_HOO),'r+')
####plt.plot(Ym-np.array(REW_POO),'c+')
####plt.plot(Ym-np.array(REW_SOO),'g+')
####plt.plot(Ym-np.array(REW_ATB),'m+')
####
###V_HCT = np.arange(n)*Ym-np.cumsum(REW_HCT)
V_HOO = np.arange(len(REW_HOO))*Ym-np.cumsum(REW_HOO)
####V_SOO = np.arange(len(REW_SOO))*Ym-np.cumsum(REW_SOO)
####V_POO = np.arange(len(REW_POO))*Ym-np.cumsum(REW_POO)
####V_ATB = np.arange(n)*Ym-np.cumsum(REW_ATB)
###
plt.figure(3)
###plt.title('Cumulative regret')
###plt.plot(V_HCT/np.arange(1,len(V_HCT)+1),'b+')
plt.plot(V_HOO,'r+')
####plt.plot(V_POO,'c+')
####plt.plot(V_SOO/np.arange(1,len(V_SOO)+1),'r+')
####plt.plot(V_ATB,'m+')
####
plt.show()
